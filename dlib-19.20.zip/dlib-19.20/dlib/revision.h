#ifndef DLIB_REVISION_H
// Version:  19.20
// Date:     Sat Jun 6 14:53:53 EDT 2020
// Git Changeset ID:  5612caa16937b5b81eb2dba17c20e303537a6a9d
#define DLIB_MAJOR_VERSION  19
#define DLIB_MINOR_VERSION  20
#define DLIB_PATCH_VERSION  0
#endif
